#!/usr/bin/env python3
# -*- coding: utf-8 -*-


class FactorizationError(Exception):
    """A generic factorization error exception
    """

    pass
